from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

db_url = "postgresql://postgres:postgres@localhost:5432/fastapi_todo"
engine = create_engine(db_url)

Base = declarative_base()

session = sessionmaker(autocommit=False, autoflush=False, bind=engine)

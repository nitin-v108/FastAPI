from fastapi import FastAPI, Path, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
from starlette import status

app = FastAPI()

# You need to add CORS Middleware like this when you use this API from different PORT like 3000 or 5000 etc...
app.add_middleware(
    CORSMiddleware, allow_origins=["http://localhost:3000"], allow_methods=["*"]
)


class Book:
    id: int
    title: str
    author: str
    description: str
    rating: int

    def __init__(self, id: int, title: str, author: str, description: str, rating: int):
        self.id = id
        self.title = title
        self.author = author
        self.description = description
        self.rating = rating


class BookRequest(BaseModel):
    id: Optional[int] = Field(description="ID not needed while creating", default=None)
    title: str = Field(min_length=3)
    author: str = Field(min_length=2)
    description: str = Field(min_length=2, max_length=100)
    rating: int = Field(gt=0, lt=6)

    model_config = {
        "json_schema_extra": {
            "example": {
                "title": "FastAPI Learning",
                "author": "Nitinkumar",
                "description": "New world",
                "rating": 5,
            }
        }
    }


BOOKS = [
    Book(1, "The Great Gatsby", "F. Scott", "A novel set in the Jazz Age.", 5),
    Book(2, "To Kill a Mockingbird", "Harper", "A novel about racial injustice.", 5),
    Book(3, "1984", "George", "A dystopian novel about totalitarianism.", 4),
]


@app.get("/books", status_code=status.HTTP_200_OK)
async def get_books():
    return BOOKS


@app.post("/books", status_code=status.HTTP_201_CREATED)
async def create_book(new_book: BookRequest):
    BOOKS.append(Book(**new_book.model_dump()))


@app.get("/books/{book_id}", status_code=status.HTTP_200_OK)
async def view_book(book_id: int = Path(gt=0)):
    for book in BOOKS:
        if book.id == book_id:
            return book
    raise HTTPException(status_code=404, detail="Book not found")


@app.get("/books/", status_code=status.HTTP_200_OK)
async def filter_book_by_rating(book_rating: int = Query(gt=0, lt=6)):
    find_book = []
    for book in BOOKS:
        if book.rating == book_rating:
            find_book.append(book)

    return find_book


@app.put("/books/update_book", status_code=status.HTTP_204_NO_CONTENT)
async def update_book(book: BookRequest):
    for i in range(len(BOOKS)):
        if BOOKS[i].id == book.id:
            BOOKS[i] = book
            return "Book updated"

    raise HTTPException(status_code=404, detail="Book not found")


@app.delete("/books/delete_book/{book_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_book(book_id: int = Path(gt=0)):
    for i in range(len(BOOKS)):
        if BOOKS[i].id == book_id:
            BOOKS.pop(i)
            return "Book deleted"

    raise HTTPException(status_code=404, detail="Book not found")
